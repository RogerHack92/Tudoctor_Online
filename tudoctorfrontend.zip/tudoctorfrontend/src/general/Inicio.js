const Inicio = () => {
    return (
        <div>Inicio</div>
    )
}

export default Inicio;